# Email Signature Extractor

## Overview

A full-stack web application that extracts email signatures from Outlook/Microsoft Graph accounts. Users can authenticate with Microsoft OAuth, process their inbox and sent items to find email signatures, and export the results to Excel format.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a modern full-stack architecture with:

- **Frontend**: React + TypeScript with Vite build system
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit OIDC + Microsoft Graph OAuth
- **UI Framework**: Tailwind CSS with shadcn/ui components

### Architecture Decisions

1. **Monorepo Structure**: Chose to organize client, server, and shared code in a single repository for easier development and deployment
2. **TypeScript Throughout**: Ensures type safety across the entire stack
3. **Drizzle ORM**: Selected for type-safe database operations and better developer experience compared to raw SQL

## Key Components

### Frontend (`client/`)
- **React Router**: Uses `wouter` for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming

### Backend (`server/`)
- **Express Server**: RESTful API with middleware for logging and error handling
- **Authentication**: Dual authentication system (Replit OIDC + Microsoft Graph)
- **Services**:
  - `microsoftGraphService`: Handles Microsoft Graph API integration
  - `signatureExtractor`: Parses email bodies to extract signature information
  - `excelGenerator`: Creates Excel files from extracted signatures

### Shared (`shared/`)
- **Database Schema**: Centralized Drizzle schema definitions
- **Type Definitions**: Shared TypeScript types between client and server

## Data Flow

1. **Authentication**: User authenticates via Replit OIDC, then connects Microsoft account
2. **Email Processing**: Server fetches emails from Microsoft Graph API
3. **Signature Extraction**: AI/regex-based extraction of signature components (name, title, company)
4. **Data Storage**: Signatures stored in PostgreSQL with user association
5. **Export**: Generated Excel files contain processed signature data

### Database Schema

- **users**: User profiles with Microsoft OAuth tokens
- **emailSignatures**: Extracted signature data with parsed components
- **processingJobs**: Track background email processing status
- **sessions**: Session storage for authentication

## External Dependencies

### Core Technologies
- **Neon Database**: Serverless PostgreSQL hosting
- **Microsoft Graph API**: Email access via OAuth2
- **Replit Authentication**: Primary user authentication

### Key Libraries
- **Frontend**: React, TanStack Query, Radix UI, Tailwind CSS
- **Backend**: Express, Drizzle ORM, ExcelJS, Passport
- **Development**: Vite, TypeScript, ESBuild

## Deployment Strategy

### Development
- Vite dev server for frontend with HMR
- tsx for backend development with auto-restart
- Integrated development experience in Replit environment

### Production
- **Frontend**: Vite build to static assets served by Express
- **Backend**: ESBuild bundles server code for production
- **Database**: Drizzle migrations for schema management
- Environment variables for configuration (DATABASE_URL, OAuth secrets)

### Build Process
1. Frontend builds to `dist/public/`
2. Backend bundles to `dist/index.js`
3. Single process serves both static assets and API routes

## Current Status (January 21, 2025)

✓ **Application Complete**: Email signature extraction web app fully built
✓ **Authentication**: Dual auth system (Replit + Microsoft OAuth) implemented
✓ **Database**: PostgreSQL with all tables created and schema deployed
✓ **Microsoft Integration**: Complete Graph API service with token management
✓ **Signature Processing**: Advanced extraction algorithm with AI parsing
✓ **Excel Export**: Full Excel generation with formatting and download
✓ **Real-time Updates**: Progress tracking with live status updates
✓ **Error Resolution**: All TypeScript and runtime errors fixed
✓ **Professional UI**: Responsive dashboard with Foundation Energy branding

**Remaining Step**: Configure Azure app registration redirect URI to complete Microsoft OAuth