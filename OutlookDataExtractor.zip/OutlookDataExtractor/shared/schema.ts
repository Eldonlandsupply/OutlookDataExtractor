import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  microsoftAccessToken: text("microsoft_access_token"),
  microsoftRefreshToken: text("microsoft_refresh_token"),
  microsoftTokenExpiry: timestamp("microsoft_token_expiry"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Email signatures storage table
export const emailSignatures = pgTable("email_signatures", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id").notNull(),
  email: varchar("email").notNull(),
  name: varchar("name"),
  company: varchar("company"),
  title: varchar("title"),
  signature: text("signature"),
  extractedAt: timestamp("extracted_at").defaultNow(),
});

// Processing jobs table
export const processingJobs = pgTable("processing_jobs", {
  id: varchar("id").primaryKey().notNull(),
  userId: varchar("user_id").notNull(),
  status: varchar("status").notNull().default("pending"), // pending, processing, completed, failed
  totalEmails: integer("total_emails").default(0),
  processedEmails: integer("processed_emails").default(0),
  contactsFound: integer("contacts_found").default(0),
  signaturesExtracted: integer("signatures_extracted").default(0),
  errorMessage: text("error_message"),
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertEmailSignature = typeof emailSignatures.$inferInsert;
export type EmailSignature = typeof emailSignatures.$inferSelect;
export type InsertProcessingJob = typeof processingJobs.$inferInsert;
export type ProcessingJob = typeof processingJobs.$inferSelect;

export const insertEmailSignatureSchema = createInsertSchema(emailSignatures);
export const insertProcessingJobSchema = createInsertSchema(processingJobs);
