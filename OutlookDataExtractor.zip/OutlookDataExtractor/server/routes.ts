import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { microsoftGraphService } from "./services/microsoftGraph";
import { signatureExtractor } from "./services/signatureExtractor";
import { excelGenerator } from "./services/excelGenerator";
import { nanoid } from "nanoid";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Debug endpoint to show redirect URI
  app.get('/api/auth/microsoft/debug', isAuthenticated, async (req: any, res) => {
    const redirectUri = `${req.protocol}://${req.get('host')}/api/auth/microsoft/callback`;
    res.json({
      redirectUri,
      clientId: process.env.MICROSOFT_CLIENT_ID,
      message: "Add this redirect URI to your Azure App Registration in the Authentication section"
    });
  });

  // Microsoft OAuth initiate
  app.get('/api/auth/microsoft', isAuthenticated, async (req: any, res) => {
    try {
      const clientId = process.env.MICROSOFT_CLIENT_ID;
      const redirectUri = `${req.protocol}://${req.get('host')}/api/auth/microsoft/callback`;
      const scope = "https://graph.microsoft.com/Mail.Read offline_access";
      
      console.log("Microsoft OAuth - Redirect URI:", redirectUri);
      console.log("Microsoft OAuth - Client ID:", clientId);
      
      const authUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=${clientId}&response_type=code&redirect_uri=${encodeURIComponent(redirectUri)}&scope=${encodeURIComponent(scope)}&response_mode=query&state=${req.user.claims.sub}`;
      
      console.log("Redirecting to:", authUrl);
      res.redirect(authUrl);
    } catch (error) {
      console.error("Error initiating Microsoft auth:", error);
      res.status(500).json({ message: "Failed to initiate Microsoft auth" });
    }
  });

  // Status check endpoint
  app.get('/api/auth/microsoft/status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const hasTokens = !!(user?.microsoftAccessToken && user?.microsoftTokenExpiry);
      const tokenExpired = hasTokens && user.microsoftTokenExpiry && new Date() > user.microsoftTokenExpiry;
      
      res.json({
        connected: hasTokens && !tokenExpired,
        hasTokens,
        tokenExpired,
        tokenExpiry: user?.microsoftTokenExpiry,
        email: user?.email
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to check Microsoft status" });
    }
  });

  // Microsoft OAuth callback
  app.get('/api/auth/microsoft/callback', async (req: any, res) => {
    try {
      console.log("===== MICROSOFT OAUTH CALLBACK RECEIVED =====");
      console.log("Full URL:", req.url);
      console.log("Query params:", req.query);
      console.log("Headers:", req.headers);
      console.log("=============================================");
      
      const { code, state, error, error_description } = req.query;
      const userId = state;
      
      if (error) {
        console.error("Microsoft OAuth error:", error, error_description);
        console.error("Full query params:", req.query);
        return res.redirect(`/?error=${encodeURIComponent(error_description || error)}`);
      }
      
      if (!code || !userId) {
        console.error("Missing authorization code or user ID. Code:", !!code, "User ID:", !!userId);
        return res.status(400).send("Missing authorization code or user ID");
      }

      // Exchange code for tokens
      const tokenUrl = "https://login.microsoftonline.com/common/oauth2/v2.0/token";
      const redirectUri = `${req.protocol}://${req.get('host')}/api/auth/microsoft/callback`;
      
      console.log("Token exchange - Redirect URI:", redirectUri);
      
      const params = new URLSearchParams({
        client_id: process.env.MICROSOFT_CLIENT_ID!,
        client_secret: process.env.MICROSOFT_CLIENT_SECRET!,
        code,
        redirect_uri: redirectUri,
        grant_type: "authorization_code",
        scope: "https://graph.microsoft.com/Mail.Read offline_access",
      });

      const response = await fetch(tokenUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: params,
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("Token exchange failed:", response.status, errorText);
        throw new Error(`Failed to exchange code for tokens: ${response.status} - ${errorText}`);
      }

      const tokenData = await response.json();
      console.log("Token exchange successful, expires in:", tokenData.expires_in);
      
      const expiryDate = new Date(Date.now() + tokenData.expires_in * 1000);

      await storage.updateUserMicrosoftTokens(
        userId,
        tokenData.access_token,
        tokenData.refresh_token,
        expiryDate
      );

      console.log("Microsoft tokens saved successfully for user:", userId);
      
      // Redirect back to dashboard
      res.redirect("/?connected=true");
    } catch (error) {
      console.error("Error in Microsoft OAuth callback:", error);
      res.redirect(`/?error=${encodeURIComponent("microsoft_auth_failed")}`);
    }
  });

  // Legacy Microsoft OAuth callback (kept for compatibility)
  app.post('/api/auth/microsoft/callback', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { access_token, refresh_token, expires_in } = req.body;
      
      if (!access_token || !refresh_token) {
        return res.status(400).json({ message: "Missing tokens" });
      }

      const expiryDate = new Date(Date.now() + expires_in * 1000);
      
      await storage.updateUserMicrosoftTokens(
        userId,
        access_token,
        refresh_token,
        expiryDate
      );

      res.json({ success: true });
    } catch (error) {
      console.error("Error saving Microsoft tokens:", error);
      res.status(500).json({ message: "Failed to save tokens" });
    }
  });

  // Start email processing
  app.post('/api/process-emails', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      // Check if user has Microsoft tokens
      const user = await storage.getUser(userId);
      if (!user?.microsoftAccessToken) {
        return res.status(400).json({ message: "Microsoft account not connected" });
      }

      // Check for existing processing job
      const existingJob = await storage.getProcessingJobByUser(userId);
      if (existingJob && existingJob.status === "processing") {
        return res.json({ jobId: existingJob.id, status: "processing" });
      }

      // Create new processing job
      const job = await storage.createProcessingJob({
        id: nanoid(),
        userId,
        status: "pending"
      });

      // Start processing in background
      processEmailsInBackground(userId, job.id);

      res.json({ jobId: job.id, status: "processing" });
    } catch (error) {
      console.error("Error starting email processing:", error);
      res.status(500).json({ message: "Failed to start processing" });
    }
  });

  // Get processing status
  app.get('/api/processing-status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const job = await storage.getProcessingJobByUser(userId);
      
      if (!job) {
        return res.json({ status: "not_started" });
      }

      res.json({
        status: job.status,
        totalEmails: job.totalEmails,
        processedEmails: job.processedEmails,
        contactsFound: job.contactsFound,
        signaturesExtracted: job.signaturesExtracted,
        errorMessage: job.errorMessage
      });
    } catch (error) {
      console.error("Error getting processing status:", error);
      res.status(500).json({ message: "Failed to get status" });
    }
  });

  // Get extracted signatures
  app.get('/api/signatures', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const signatures = await storage.getEmailSignaturesByUser(userId);
      res.json(signatures);
    } catch (error) {
      console.error("Error getting signatures:", error);
      res.status(500).json({ message: "Failed to get signatures" });
    }
  });

  // Export signatures to Excel
  app.get('/api/export-excel', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const signatures = await storage.getEmailSignaturesByUser(userId);
      
      if (signatures.length === 0) {
        return res.status(400).json({ message: "No signatures to export" });
      }

      const excelBuffer = await excelGenerator.generateSignatureExcel(signatures);
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=Email_Signatures.xlsx');
      res.send(excelBuffer);
    } catch (error) {
      console.error("Error exporting Excel:", error);
      res.status(500).json({ message: "Failed to export Excel" });
    }
  });

  // Background email processing function
  async function processEmailsInBackground(userId: string, jobId: string) {
    try {
      await storage.updateProcessingJob(jobId, { status: "processing" });

      // Clear previous signatures for this user
      await storage.deleteEmailSignaturesByUser(userId);

      // Get inbox emails
      const inboxEmails = await microsoftGraphService.getInboxEmails(userId);
      const sentEmails = await microsoftGraphService.getSentEmails(userId);
      const allEmails = [...inboxEmails, ...sentEmails];

      await storage.updateProcessingJob(jobId, { totalEmails: allEmails.length });

      let processedEmails = 0;
      let contactsFound = 0;
      let signaturesExtracted = 0;
      const processedContacts = new Set<string>();

      for (const email of allEmails) {
        try {
          // Extract contact email addresses
          const contacts: Array<{ email: string; name?: string }> = [];
          
          // From inbox emails, get sender info
          if (email.from?.emailAddress?.address && 
              !email.from.emailAddress.address.includes("foundationenergy.com")) {
            contacts.push({
              email: email.from.emailAddress.address.toLowerCase(),
              name: email.from.emailAddress.name
            });
          }

          // From sent emails, get recipient info
          if (email.toRecipients) {
            for (const recipient of email.toRecipients) {
              if (recipient.emailAddress?.address && 
                  !recipient.emailAddress.address.includes("foundationenergy.com")) {
                contacts.push({
                  email: recipient.emailAddress.address.toLowerCase(),
                  name: recipient.emailAddress.name
                });
              }
            }
          }

          // Process unique contacts
          for (const contact of contacts) {
            if (!processedContacts.has(contact.email)) {
              processedContacts.add(contact.email);
              contactsFound++;

              // Extract signature
              const signature = signatureExtractor.extractSignature(email.body?.content || "");
              
              if (signature) {
                await storage.insertEmailSignature({
                  id: nanoid(),
                  userId,
                  email: contact.email,
                  name: signature.name || contact.name || "",
                  company: signature.company || "",
                  title: signature.title || "",
                  signature: signature.fullSignature
                });
                signaturesExtracted++;
              }
            }
          }

          processedEmails++;

          // Update progress every 50 emails
          if (processedEmails % 50 === 0) {
            await storage.updateProcessingJob(jobId, {
              processedEmails,
              contactsFound,
              signaturesExtracted
            });
          }

        } catch (emailError) {
          console.error("Error processing email:", emailError);
          // Continue processing other emails
        }
      }

      // Final update
      await storage.updateProcessingJob(jobId, {
        status: "completed",
        processedEmails,
        contactsFound,
        signaturesExtracted,
        completedAt: new Date()
      });

    } catch (error) {
      console.error("Error in background processing:", error);
      await storage.updateProcessingJob(jobId, {
        status: "failed",
        errorMessage: error instanceof Error ? error.message : "Unknown error"
      });
    }
  }

  const httpServer = createServer(app);
  return httpServer;
}
