import {
  users,
  emailSignatures,
  processingJobs,
  type User,
  type UpsertUser,
  type EmailSignature,
  type InsertEmailSignature,
  type ProcessingJob,
  type InsertProcessingJob,
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserMicrosoftTokens(
    id: string,
    accessToken: string,
    refreshToken: string,
    expiryDate: Date
  ): Promise<void>;

  // Email signature operations
  getEmailSignaturesByUser(userId: string): Promise<EmailSignature[]>;
  insertEmailSignature(signature: InsertEmailSignature): Promise<EmailSignature>;
  deleteEmailSignaturesByUser(userId: string): Promise<void>;

  // Processing job operations
  getProcessingJobByUser(userId: string): Promise<ProcessingJob | undefined>;
  createProcessingJob(job: InsertProcessingJob): Promise<ProcessingJob>;
  updateProcessingJob(
    id: string,
    updates: Partial<ProcessingJob>
  ): Promise<ProcessingJob>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserMicrosoftTokens(
    id: string,
    accessToken: string,
    refreshToken: string,
    expiryDate: Date
  ): Promise<void> {
    await db
      .update(users)
      .set({
        microsoftAccessToken: accessToken,
        microsoftRefreshToken: refreshToken,
        microsoftTokenExpiry: expiryDate,
        updatedAt: new Date(),
      })
      .where(eq(users.id, id));
  }

  async getEmailSignaturesByUser(userId: string): Promise<EmailSignature[]> {
    return await db
      .select()
      .from(emailSignatures)
      .where(eq(emailSignatures.userId, userId));
  }

  async insertEmailSignature(
    signature: InsertEmailSignature
  ): Promise<EmailSignature> {
    const [result] = await db
      .insert(emailSignatures)
      .values(signature)
      .returning();
    return result;
  }

  async deleteEmailSignaturesByUser(userId: string): Promise<void> {
    await db
      .delete(emailSignatures)
      .where(eq(emailSignatures.userId, userId));
  }

  async getProcessingJobByUser(userId: string): Promise<ProcessingJob | undefined> {
    const [job] = await db
      .select()
      .from(processingJobs)
      .where(eq(processingJobs.userId, userId))
      .orderBy(processingJobs.startedAt);
    return job;
  }

  async createProcessingJob(job: InsertProcessingJob): Promise<ProcessingJob> {
    const [result] = await db.insert(processingJobs).values(job).returning();
    return result;
  }

  async updateProcessingJob(
    id: string,
    updates: Partial<ProcessingJob>
  ): Promise<ProcessingJob> {
    const [result] = await db
      .update(processingJobs)
      .set(updates)
      .where(eq(processingJobs.id, id))
      .returning();
    return result;
  }
}

export const storage = new DatabaseStorage();
