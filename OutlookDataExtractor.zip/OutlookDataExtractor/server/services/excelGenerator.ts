import ExcelJS from "exceljs";
import type { EmailSignature } from "@shared/schema";

export class ExcelGenerator {
  async generateSignatureExcel(signatures: EmailSignature[]): Promise<Buffer> {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Email Signatures");

    // Add headers
    worksheet.addRow([
      "Name",
      "Email",
      "Company", 
      "Title",
      "Full Signature",
      "Extracted Date"
    ]);

    // Style headers
    const headerRow = worksheet.getRow(1);
    headerRow.font = { bold: true };
    headerRow.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFE7F3FF" }
    };

    // Add data rows
    signatures.forEach(signature => {
      worksheet.addRow([
        signature.name || "",
        signature.email || "",
        signature.company || "",
        signature.title || "",
        signature.signature || "",
        signature.extractedAt ? signature.extractedAt.toISOString().split('T')[0] : ""
      ]);
    });

    // Auto-fit columns
    worksheet.columns.forEach(column => {
      let maxLength = 0;
      column.eachCell?.({ includeEmpty: true }, cell => {
        const cellLength = cell.value ? cell.value.toString().length : 0;
        maxLength = Math.max(maxLength, cellLength);
      });
      column.width = Math.min(Math.max(maxLength + 2, 10), 50);
    });

    // Generate buffer
    const buffer = await workbook.xlsx.writeBuffer();
    return Buffer.from(buffer);
  }
}

export const excelGenerator = new ExcelGenerator();
