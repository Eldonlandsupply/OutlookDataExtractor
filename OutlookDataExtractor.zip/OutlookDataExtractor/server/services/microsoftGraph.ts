import { storage } from "../storage";

interface GraphApiResponse {
  value: any[];
  "@odata.nextLink"?: string;
}

interface EmailMessage {
  id: string;
  subject: string;
  body: {
    content: string;
    contentType: string;
  };
  from?: {
    emailAddress: {
      address: string;
      name: string;
    };
  };
  toRecipients?: Array<{
    emailAddress: {
      address: string;
      name: string;
    };
  }>;
  sender?: {
    emailAddress: {
      address: string;
      name: string;
    };
  };
}

export class MicrosoftGraphService {
  private baseUrl = "https://graph.microsoft.com/v1.0";

  async refreshAccessToken(userId: string): Promise<string> {
    const user = await storage.getUser(userId);
    if (!user?.microsoftRefreshToken) {
      throw new Error("No refresh token available");
    }

    const tokenUrl = "https://login.microsoftonline.com/common/oauth2/v2.0/token";
    const params = new URLSearchParams({
      client_id: process.env.MICROSOFT_CLIENT_ID || "",
      client_secret: process.env.MICROSOFT_CLIENT_SECRET || "",
      refresh_token: user.microsoftRefreshToken,
      grant_type: "refresh_token",
      scope: "https://graph.microsoft.com/Mail.Read offline_access",
    });

    const response = await fetch(tokenUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: params,
    });

    if (!response.ok) {
      throw new Error("Failed to refresh access token");
    }

    const tokenData = await response.json();
    const expiryDate = new Date(Date.now() + tokenData.expires_in * 1000);

    await storage.updateUserMicrosoftTokens(
      userId,
      tokenData.access_token,
      tokenData.refresh_token || user.microsoftRefreshToken,
      expiryDate
    );

    return tokenData.access_token;
  }

  async getAccessToken(userId: string): Promise<string> {
    const user = await storage.getUser(userId);
    if (!user?.microsoftAccessToken) {
      throw new Error("No access token available");
    }

    // Check if token is expired
    if (user.microsoftTokenExpiry && new Date() >= user.microsoftTokenExpiry) {
      return await this.refreshAccessToken(userId);
    }

    return user.microsoftAccessToken;
  }

  async makeGraphRequest(userId: string, endpoint: string): Promise<any> {
    const accessToken = await this.getAccessToken(userId);
    
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        // Try refreshing token once
        const newAccessToken = await this.refreshAccessToken(userId);
        const retryResponse = await fetch(`${this.baseUrl}${endpoint}`, {
          headers: {
            Authorization: `Bearer ${newAccessToken}`,
            "Content-Type": "application/json",
          },
        });
        
        if (!retryResponse.ok) {
          throw new Error(`Graph API request failed: ${retryResponse.status}`);
        }
        return await retryResponse.json();
      }
      throw new Error(`Graph API request failed: ${response.status}`);
    }

    return await response.json();
  }

  async getAllEmails(userId: string, folderName: "inbox" | "sentitems"): Promise<EmailMessage[]> {
    const emails: EmailMessage[] = [];
    let nextLink: string | undefined = `/me/mailFolders/${folderName}/messages?$select=id,subject,body,from,toRecipients,sender&$top=100`;

    while (nextLink) {
      const response: GraphApiResponse = await this.makeGraphRequest(userId, nextLink);
      emails.push(...response.value);
      
      nextLink = response["@odata.nextLink"]
        ? response["@odata.nextLink"].replace(this.baseUrl, "")
        : undefined;
    }

    return emails;
  }

  async getInboxEmails(userId: string): Promise<EmailMessage[]> {
    return await this.getAllEmails(userId, "inbox");
  }

  async getSentEmails(userId: string): Promise<EmailMessage[]> {
    return await this.getAllEmails(userId, "sentitems");
  }
}

export const microsoftGraphService = new MicrosoftGraphService();
