interface ParsedSignature {
  name?: string;
  title?: string;
  company?: string;
  phone?: string;
  email?: string;
  fullSignature: string;
}

export class SignatureExtractor {
  private signatureStartKeywords = [
    "best regards",
    "sincerely",
    "thanks",
    "thank you",
    "regards",
    "cheers",
    "warm regards",
    "kind regards",
    "yours truly",
    "respectfully",
  ];

  private phoneRegex = /(\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4})/g;
  private emailRegex = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/g;

  extractSignature(emailBody: string): ParsedSignature | null {
    if (!emailBody) return null;

    // Convert HTML to plain text if needed
    const plainText = this.htmlToPlainText(emailBody);
    const lines = plainText.split(/\r?\n/).map(line => line.trim()).filter(line => line.length > 0);

    // Find signature start
    const signatureStartIndex = this.findSignatureStart(lines);
    if (signatureStartIndex === -1) return null;

    // Extract signature lines
    const signatureLines = lines.slice(signatureStartIndex);
    if (signatureLines.length < 2) return null;

    const fullSignature = signatureLines.join("\n");

    // Parse signature components
    const parsed = this.parseSignatureComponents(signatureLines);
    
    return {
      ...parsed,
      fullSignature,
    };
  }

  private htmlToPlainText(html: string): string {
    return html
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/div>/gi, "\n")
      .replace(/<\/p>/gi, "\n")
      .replace(/<[^>]*>/g, "")
      .replace(/&nbsp;/g, " ")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;/g, "'");
  }

  private findSignatureStart(lines: string[]): number {
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].toLowerCase();
      if (this.signatureStartKeywords.some(keyword => line.includes(keyword))) {
        return i;
      }
    }

    // If no signature keyword found, look for patterns that might indicate signature
    for (let i = Math.max(0, lines.length - 15); i < lines.length; i++) {
      const line = lines[i];
      // Look for patterns like name followed by title/company
      if (this.looksLikePersonName(line) && i + 1 < lines.length) {
        const nextLine = lines[i + 1];
        if (this.looksLikeTitleOrCompany(nextLine)) {
          return i;
        }
      }
    }

    return -1;
  }

  private looksLikePersonName(line: string): boolean {
    // Simple heuristic: 2-4 words, each starting with capital letter, no email/phone/url patterns
    const words = line.split(/\s+/).filter(word => word.length > 0);
    if (words.length < 2 || words.length > 4) return false;
    
    // Check if most words start with capital letter
    const capitalWords = words.filter(word => /^[A-Z]/.test(word));
    if (capitalWords.length < words.length * 0.7) return false;

    // Exclude lines with email, phone, or URL patterns
    if (this.emailRegex.test(line) || this.phoneRegex.test(line) || line.includes("http")) {
      return false;
    }

    return true;
  }

  private looksLikeTitleOrCompany(line: string): boolean {
    const titleKeywords = [
      "ceo", "cto", "cfo", "president", "director", "manager", "analyst",
      "coordinator", "specialist", "engineer", "developer", "consultant",
      "advisor", "partner", "founder", "vice president", "vp", "senior",
      "junior", "lead", "head", "chief"
    ];

    const lowerLine = line.toLowerCase();
    return titleKeywords.some(keyword => lowerLine.includes(keyword));
  }

  private parseSignatureComponents(lines: string[]): Partial<ParsedSignature> {
    const result: Partial<ParsedSignature> = {};
    
    // First non-greeting line is likely the name
    let nameLineIndex = 0;
    const firstLine = lines[0].toLowerCase();
    if (this.signatureStartKeywords.some(keyword => firstLine.includes(keyword))) {
      nameLineIndex = 1;
    }

    if (nameLineIndex < lines.length && this.looksLikePersonName(lines[nameLineIndex])) {
      result.name = lines[nameLineIndex];
    }

    // Look for title and company in subsequent lines
    for (let i = nameLineIndex + 1; i < Math.min(lines.length, nameLineIndex + 5); i++) {
      const line = lines[i];
      
      if (!result.title && this.looksLikeTitleOrCompany(line)) {
        result.title = line;
      } else if (!result.company && !this.looksLikeTitleOrCompany(line) && 
                 !this.phoneRegex.test(line) && !this.emailRegex.test(line) &&
                 !line.toLowerCase().includes("phone") && !line.toLowerCase().includes("email")) {
        // Could be company name
        result.company = line;
      }
    }

    // Extract phone and email from any line
    const fullText = lines.join(" ");
    const phoneMatches = fullText.match(this.phoneRegex);
    if (phoneMatches && phoneMatches.length > 0) {
      result.phone = phoneMatches[0];
    }

    const emailMatches = fullText.match(this.emailRegex);
    if (emailMatches && emailMatches.length > 0) {
      result.email = emailMatches[0];
    }

    return result;
  }
}

export const signatureExtractor = new SignatureExtractor();
