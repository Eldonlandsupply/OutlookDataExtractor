# Azure App Registration Guide

## Complete Setup Instructions

### Step 1: Create New App Registration

1. **Go to Azure Portal**
   - Visit: https://portal.azure.com
   - Sign in with your Microsoft account

2. **Navigate to App Registrations**
   - In the search bar, type "App registrations"
   - Click on "App registrations" from the results

3. **Create New Registration**
   - Click "New registration" button
   - Fill out the form:
     - **Name**: `Email Signature Extractor` (or any name you prefer)
     - **Supported account types**: Select "Accounts in any organizational directory and personal Microsoft accounts"
     - **Redirect URI**: Select "Web" and enter:
       ```
       https://12897e61-dd67-4ca0-a82f-2843893d94f0-00-13as1n4igs3ru.spock.replit.dev/api/auth/microsoft/callback
       ```
   - Click "Register"

### Step 2: Configure Authentication

1. **Go to Authentication**
   - In your new app registration, click "Authentication" in the left menu
   - Verify your redirect URI is listed
   - Under "Implicit grant and hybrid flows":
     - ✅ Check "Access tokens (used for implicit flows)"
     - ✅ Check "ID tokens (used for implicit and hybrid flows)"
   - Click "Save"

### Step 3: Set API Permissions

1. **Go to API Permissions**
   - Click "API permissions" in the left menu
   - Click "Add a permission"
   - Select "Microsoft Graph"
   - Select "Delegated permissions"
   - Search for and add these permissions:
     - ✅ `Mail.Read` - Read user mail
     - ✅ `offline_access` - Maintain access to data you have given it access to
   - Click "Add permissions"

2. **Grant Admin Consent** (if you're an admin)
   - Click "Grant admin consent for [Your Organization]"
   - Click "Yes" to confirm

### Step 4: Create Client Secret

1. **Go to Certificates & secrets**
   - Click "Certificates & secrets" in the left menu
   - Click "New client secret"
   - Add description: `Email Signature Extractor Secret`
   - Choose expiration: 24 months (recommended)
   - Click "Add"
   - **IMPORTANT**: Copy the secret value immediately (it won't be shown again)

### Step 5: Get Your Credentials

After creating the app registration, you'll need these values:

1. **Application (client) ID**: Found on the "Overview" page
2. **Client Secret**: The value you just copied
3. **Redirect URI**: The URL you configured in authentication

### Step 6: Update Environment Variables

You'll need to set these environment variables in your Replit:

```
MICROSOFT_CLIENT_ID=your-application-client-id
MICROSOFT_CLIENT_SECRET=your-client-secret-value
```

### Step 7: Test the Connection

1. After updating the environment variables
2. Restart your application
3. Click "Connect Microsoft Account"
4. You should be redirected to Microsoft login
5. After login, you'll be redirected back to your app

## Troubleshooting

### Common Issues:

1. **Redirect URI Mismatch**
   - Make sure the redirect URI in Azure exactly matches what your app is using
   - Check for https vs http
   - Check for trailing slashes

2. **Permission Issues**
   - Ensure Mail.Read and offline_access are granted
   - Grant admin consent if needed

3. **Client Secret Expired**
   - Generate a new client secret
   - Update the MICROSOFT_CLIENT_SECRET environment variable

### Current App Details:
- Your app should redirect to: `https://12897e61-dd67-4ca0-a82f-2843893d94f0-00-13as1n4igs3ru.spock.replit.dev/api/auth/microsoft/callback`
- Required permissions: `Mail.Read`, `offline_access`
- Account types: Personal and organizational accounts