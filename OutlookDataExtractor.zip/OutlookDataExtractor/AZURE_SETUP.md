# Azure App Registration Setup

## Required Configuration

To make Microsoft OAuth work, you need to configure your Azure App Registration:

### 1. Redirect URI
Add this exact redirect URI to your Azure app registration:
```
https://12897e61-dd67-4ca0-a82f-2843893d94f0-00-13as1n4igs3ru.spock.replit.dev/api/auth/microsoft/callback
```

### 2. Steps to Configure:
1. Go to [Azure Portal](https://portal.azure.com)
2. Navigate to: Azure Active Directory → App registrations
3. Find your app with Client ID: `bfeec55a-d1b1-460b-8afd-b055784c62bc`
4. Go to "Authentication" tab
5. Click "Add a platform" → "Web"
6. Add the redirect URI above
7. Save changes

### 3. Required API Permissions:
Ensure these permissions are granted in "API permissions":
- `Microsoft Graph` → `Mail.Read` (Application or Delegated)
- `Microsoft Graph` → `offline_access` (Delegated)

### 4. Grant Admin Consent:
After adding permissions, click "Grant admin consent" if you're an admin.

## Current Status:
- ✅ Application code is complete and working
- ✅ Microsoft OAuth flow is implemented
- ⏳ Waiting for Azure redirect URI configuration
- ⏳ Once configured, the "Connect Microsoft Account" button will work

## Testing:
After configuration, test by:
1. Click "Connect Microsoft Account" 
2. Complete Microsoft login
3. Should redirect back with success message
4. Then click "Start Processing" to extract email signatures