import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import ProcessingProgress from "@/components/ProcessingProgress";
import ContactsTable from "@/components/ContactsTable";
import type { EmailSignature, User } from "@shared/schema";

interface ProcessingStatus {
  status: string;
  totalEmails?: number;
  processedEmails?: number;
  contactsFound?: number;
  signaturesExtracted?: number;
  errorMessage?: string;
}

export default function Dashboard() {
  const { user } = useAuth() as { user: User | undefined };
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [microsoftConnected, setMicrosoftConnected] = useState(false);

  // Check for OAuth callback parameters
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const connected = urlParams.get('connected');
    const error = urlParams.get('error');
    
    if (connected === 'true') {
      setMicrosoftConnected(true);
      toast({
        title: "Success",
        description: "Microsoft account connected successfully!",
        variant: "default",
      });
      // Clean up URL
      window.history.replaceState({}, '', window.location.pathname);
    } else if (error) {
      let errorMessage = "Failed to connect Microsoft account";
      
      if (error.includes('redirect_uri_mismatch')) {
        errorMessage = "Redirect URI mismatch. Please configure Azure App Registration with the correct redirect URI.";
      } else if (error.includes('invalid_client')) {
        errorMessage = "Invalid client ID. Please check your Microsoft OAuth configuration.";
      } else if (error === 'microsoft_auth_failed') {
        errorMessage = "Microsoft authentication failed. Please try again.";
      }
      
      toast({
        title: "Microsoft OAuth Error",
        description: errorMessage,
        variant: "destructive",
      });
      // Clean up URL
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [toast]);

  // Check if user has Microsoft tokens
  useEffect(() => {
    if (user?.microsoftAccessToken) {
      setMicrosoftConnected(true);
    }
  }, [user]);

  // Get processing status
  const { data: processingStatus, refetch: refetchStatus } = useQuery<ProcessingStatus>({
    queryKey: ["/api/processing-status"],
    refetchInterval: 2000,
    enabled: true,
  });

  // Get signatures
  const { data: signatures = [] } = useQuery<EmailSignature[]>({
    queryKey: ["/api/signatures"],
    enabled: processingStatus?.status === "completed",
  });

  // Start processing mutation
  const processEmailsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/process-emails");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/processing-status"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleMicrosoftConnect = () => {
    window.location.href = "/api/auth/microsoft";
  };

  const handleStartProcessing = () => {
    processEmailsMutation.mutate();
  };

  const handleExportExcel = () => {
    window.open("/api/export-excel", "_blank");
  };

  const handleSignOut = () => {
    window.location.href = "/api/logout";
  };

  const handleShowAzureConfig = async () => {
    try {
      const response = await fetch("/api/auth/microsoft/debug");
      const data = await response.json();
      
      // Copy to clipboard for easier use
      const configText = `Azure App Registration Configuration:

Redirect URI: ${data.redirectUri}
Client ID: ${data.clientId}

Steps:
1. Go to https://portal.azure.com
2. Search for "App registrations"
3. Find your app with Client ID: ${data.clientId}
4. Click on "Authentication" in the left menu
5. Click "Add a platform" → "Web"
6. Paste this redirect URI: ${data.redirectUri}
7. Check "ID tokens" and "Access tokens"
8. Save changes
9. Go to "API permissions"
10. Ensure you have: Microsoft Graph → Mail.Read (Delegated)
11. Ensure you have: Microsoft Graph → offline_access (Delegated)
12. Grant admin consent if needed`;

      navigator.clipboard.writeText(configText).then(() => {
        toast({
          title: "Configuration Copied!",
          description: "Azure configuration details copied to clipboard. Follow the steps to configure your app registration.",
        });
      }).catch(() => {
        alert(configText);
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get Azure configuration info",
        variant: "destructive",
      });
    }
  };

  const stats = {
    totalEmails: processingStatus?.totalEmails || 0,
    uniqueContacts: processingStatus?.contactsFound || 0,
    signaturesExtracted: processingStatus?.signaturesExtracted || 0,
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="bg-primary text-white p-2 rounded-lg">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                  <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-semibold text-gray-900">Email Signature Extractor</h1>
                <p className="text-sm text-gray-500">Foundation Energy</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-3">
                <img 
                  src={user?.profileImageUrl || `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.firstName + ' ' + user?.lastName || 'User')}&background=1976D2&color=fff`}
                  alt="User Avatar" 
                  className="w-8 h-8 rounded-full object-cover"
                />
                <span className="text-sm text-gray-700">{user?.email}</span>
                <button 
                  onClick={handleSignOut}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {!microsoftConnected ? (
          <div className="max-w-md mx-auto">
            <Card className="shadow-sm">
              <CardContent className="p-8">
                <div className="text-center mb-8">
                  <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-primary" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M23.5 7h-15v2h15v-2zM8.5 6V4H0V3h8.5V1.5L12 5L8.5 8.5V7z"/>
                    </svg>
                  </div>
                  <h2 className="text-2xl font-semibold text-gray-900 mb-2">Connect Your Outlook</h2>
                  <p className="text-gray-600">Connect your Microsoft account to start extracting email signatures.</p>
                </div>

                <div className="space-y-3">
                  <Button 
                    onClick={handleMicrosoftConnect}
                    className="w-full bg-primary hover:bg-blue-700 text-white font-medium py-3 px-4 rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2"
                  >
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M0 0h11.377v11.372H0zm12.623 0H24v11.372H12.623zM0 12.623h11.377V24H0zm12.623 0H24V24H12.623"/>
                    </svg>
                    <span>Connect Microsoft Account</span>
                  </Button>
                  
                  <Button 
                    onClick={handleShowAzureConfig}
                    variant="outline"
                    className="w-full text-gray-600 border-gray-300 hover:bg-gray-50"
                  >
                    <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                    Need Help? Show Azure Config
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        ) : (
          <>
            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="bg-blue-100 p-3 rounded-lg">
                      <svg className="w-6 h-6 text-primary" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                        <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                      </svg>
                    </div>
                    <span className="text-2xl font-bold text-gray-900">{stats.totalEmails.toLocaleString()}</span>
                  </div>
                  <h3 className="font-medium text-gray-900 mb-1">Total Emails Processed</h3>
                  <p className="text-sm text-gray-500">From inbox and sent items</p>
                </CardContent>
              </Card>

              <Card className="shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="bg-green-100 p-3 rounded-lg">
                      <svg className="w-6 h-6 text-accent" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                    <span className="text-2xl font-bold text-gray-900">{stats.uniqueContacts}</span>
                  </div>
                  <h3 className="font-medium text-gray-900 mb-1">External Contacts Found</h3>
                  <p className="text-sm text-gray-500">Excluding @foundationenergy.com</p>
                </CardContent>
              </Card>

              <Card className="shadow-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="bg-purple-100 p-3 rounded-lg">
                      <svg className="w-6 h-6 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M4 4a2 2 0 012-2h8a2 2 0 012 2v12a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 0v12h8V4H6z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <span className="text-2xl font-bold text-gray-900">{stats.signaturesExtracted}</span>
                  </div>
                  <h3 className="font-medium text-gray-900 mb-1">Signatures Extracted</h3>
                  <p className="text-sm text-gray-500">With complete contact info</p>
                </CardContent>
              </Card>
            </div>

            {/* Processing Progress */}
            {processingStatus?.status === "processing" && (
              <ProcessingProgress status={{
                totalEmails: processingStatus.totalEmails || 0,
                processedEmails: processingStatus.processedEmails || 0,
                contactsFound: processingStatus.contactsFound || 0,
                signaturesExtracted: processingStatus.signaturesExtracted || 0,
              }} />
            )}

            {/* Actions Bar */}
            <Card className="shadow-sm mb-8">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center space-y-4 sm:space-y-0">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">Email Processing</h3>
                    <p className="text-sm text-gray-600">
                      {processingStatus?.status === "completed" 
                        ? "Processing complete. Download your results below."
                        : "Start processing your emails to extract signatures."
                      }
                    </p>
                  </div>
                  <div className="flex space-x-3">
                    {processingStatus?.status === "completed" && signatures.length > 0 && (
                      <Button 
                        onClick={handleExportExcel}
                        className="bg-accent hover:bg-green-600 text-white font-medium py-2 px-4 rounded-lg transition-colors duration-200 flex items-center space-x-2"
                      >
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                        <span>Download Excel</span>
                      </Button>
                    )}
                    <Button 
                      onClick={handleStartProcessing}
                      disabled={processEmailsMutation.isPending || processingStatus?.status === "processing"}
                      variant="outline"
                      className="font-medium py-2 px-4 rounded-lg transition-colors duration-200 flex items-center space-x-2"
                    >
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
                      </svg>
                      <span>{processingStatus?.status === "processing" ? "Processing..." : "Start Processing"}</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contacts Table */}
            {signatures.length > 0 && <ContactsTable signatures={signatures} />}
          </>
        )}
      </main>
    </div>
  );
}
