interface ProcessingProgressProps {
  status: {
    totalEmails: number;
    processedEmails: number;
    contactsFound: number;
    signaturesExtracted: number;
  };
}

export default function ProcessingProgress({ status }: ProcessingProgressProps) {
  const percentage = status.totalEmails > 0 
    ? Math.round((status.processedEmails / status.totalEmails) * 100)
    : 0;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-8">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Processing Emails</h3>
        <span className="text-sm text-gray-500">{percentage}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2 mb-4">
        <div 
          className="bg-primary h-2 rounded-full transition-all duration-300" 
          style={{ width: `${percentage}%` }}
        />
      </div>
      <div className="flex justify-between text-sm text-gray-600">
        <span>Scanning emails...</span>
        <span>{status.processedEmails.toLocaleString()} / {status.totalEmails.toLocaleString()} emails</span>
      </div>
      <div className="flex justify-between text-xs text-gray-500 mt-2">
        <span>{status.contactsFound} contacts found</span>
        <span>{status.signaturesExtracted} signatures extracted</span>
      </div>
    </div>
  );
}
