import { Button } from "@/components/ui/button";
import type { EmailSignature } from "@shared/schema";

interface SignatureModalProps {
  signature: EmailSignature;
  onClose: () => void;
}

export default function SignatureModal({ signature, onClose }: SignatureModalProps) {
  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50"
      onClick={handleBackdropClick}
    >
      <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full mx-4 max-h-96">
        <div className="flex justify-between items-center p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Full Email Signature</h3>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </Button>
        </div>
        <div className="p-6">
          <div className="bg-gray-50 rounded-lg p-4 font-mono text-sm text-gray-800 whitespace-pre-line max-h-64 overflow-y-auto">
            {signature.signature || "No signature available"}
          </div>
          
          {(signature.name || signature.title || signature.company) && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Extracted Information:</h4>
              <div className="grid grid-cols-2 gap-4 text-sm">
                {signature.name && (
                  <div>
                    <span className="font-medium text-gray-600">Name:</span>
                    <span className="ml-2 text-gray-900">{signature.name}</span>
                  </div>
                )}
                {signature.title && (
                  <div>
                    <span className="font-medium text-gray-600">Title:</span>
                    <span className="ml-2 text-gray-900">{signature.title}</span>
                  </div>
                )}
                {signature.company && (
                  <div>
                    <span className="font-medium text-gray-600">Company:</span>
                    <span className="ml-2 text-gray-900">{signature.company}</span>
                  </div>
                )}
                {signature.email && (
                  <div>
                    <span className="font-medium text-gray-600">Email:</span>
                    <span className="ml-2 text-gray-900">{signature.email}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
